package com.example.springbootmonolith.repositories;

import org.springframework.data.repository.CrudRepository;
import com.example.springbootmonolith.models.Song;


public interface SongRepository extends CrudRepository<Song, Long> {
}

