create table SONGS (
    ID serial,
    TITLE varchar(100) NOT NULL,
    LEN varchar(100) NOT NULL
);