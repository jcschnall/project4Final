create table USERS (
    ID serial,
    USER_NAME varchar(100) NOT NULL
);