INSERT INTO USERS
    (USER_NAME,FIRST_NAME,LAST_NAME)
VALUES
    ('userFromSeeds','user', 'from seeds'),
    ('anotherUser','another', 'user'),
    ('someoneElse','someone','else'),
    ('someoneDifferent','someone', 'different');

INSERT INTO SONGS
    (TITLE, LEN)
VALUES
    ('A_SONG', '3mins'),
    ('A_SONG', '3mins'),
    ('A_SONG', '3mins'),
    ('A_SONG', '3mins');

