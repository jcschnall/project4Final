alter table users
add column FIRST_NAME varchar(100) not null,
add column LAST_NAME varchar(100) not null;
